#!/usr/bin/env node

var mdns = require('../lib/mdns')
  , ad = mdns.createAdvertisement(mdns.tcp('some-service'), 2342, function(err, service) {
      if (err) {
        console.log('ERROR:', err);
      } else {
        console.log(service);
      }
    });

ad.start();

