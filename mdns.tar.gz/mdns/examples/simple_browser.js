#!/usr/bin/env node

var mdns = require('../lib/mdns')
  , browser = mdns.createBrowser(mdns.tcp('some-service'))
  ;

setTimeout(function(){console.log('time')}, 5000);
browser.on('serviceChanged', function(service) { console.log(service); });
browser.on('error', function(err) { console.log('ERROR', err); });
browser.start();

